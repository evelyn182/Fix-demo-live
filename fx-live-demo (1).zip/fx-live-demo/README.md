# FX DEMO LIVE

## Deploy
1. Create a Twelve Data API key.
2. In Netlify: Project configuration → Environment variables, add:
   `TWELVE_DATA_API_KEY`
3. Deploy this folder.
4. Open the site.

The browser calls the Netlify Function; the API key remains server-side.

## Features
- EUR/USD provider candles: 15m, 1H, 4H
- 4H trend → 1H pullback/RSI → 15m confirmation
- Closed-candle BUY/SELL/WAIT signal
- Automatic historical backtest date range
- 1% simulated risk, 1:2 target

This is demo/research software. Historical performance is not a guarantee of future results. The current backtester is a compact prototype and should be extended with spread, slippage, trading-session rules and robust multi-timeframe alignment before relying on results.
